#!/bin/sh

autoconf --warnings=all
autoheader --warnings=all
